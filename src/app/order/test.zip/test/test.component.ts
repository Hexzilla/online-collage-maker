import {
  Component,
  OnInit,
  Input,
  Output,
  ViewChild,
  Renderer2,
  ElementRef,
  EventEmitter,
} from '@angular/core';
import * as _ from 'lodash';
import { CanvasComponent } from '../canvas/canvas.component';
import { SharedService } from 'src/app/shared.service';
import { MatDialog } from '@angular/material';
import { NeworderService } from 'src/app/services/neworder.service';

export interface Size {
  fixedSize: number;
  recommendedSize: number;
  gallaryWrap: number;
  rolledCanvas: number;
  customerSelected: string;
}

@Component({
  selector: 'app-size',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss'],
})
export class TestComponent implements OnInit {
  @ViewChild('table', { static: false }) table;
  @Output() onSizeChange: EventEmitter<any> = new EventEmitter();
  imgConstant = [8, 10, 12, 16, 18, 20, 24, 30, 36, 42, 48, 60, 72, 84, 90];
  res: Size[] = [];
  private _img: any;
  customHeight: number[] = [];
  customWidth: number[] = [];
  selectedCustomHeight: number;
  selectedCustomWidth: number;
  gcustomRate: number;
  ccustomRate: number;
  imgsrc: any;
  dataUrl: any;

  mainImage = 'assets/gallarybg/2.webp';
  bgimgs = [
    // 'assets/gallarybg/1.webp',
    'assets/gallarybg/2.webp',
    'assets/gallarybg/3.webp',
    // 'assets/gallarybg/4.webp',
    // 'assets/gallarybg/5.webp',
    'assets/gallarybg/6.webp',
    'assets/gallarybg/7.webp',
    'assets/gallarybg/8.webp',
    'assets/gallarybg/9.webp',
    'assets/gallarybg/10.webp',
    // 'assets/gallarybg/11.webp',
    'assets/gallarybg/12.webp',
    'assets/gallarybg/13.webp',
    // 'assets/gallarybg/14.webp',
    'assets/gallarybg/15.webp',
    // 'assets/gallarybg/16.webp',
    'assets/gallarybg/17.webp',
    'assets/gallarybg/18.webp',
  ];

  @Input()
  set size(val) {
    if (val) {
      this.show(val.height, val.width);
    }
  }

  roundOf(val) {
    return Math.round(val);
  }

  constructor(
    public dialog: MatDialog,
    private renderer: Renderer2,
    private el: ElementRef,
    private sharedSvc: SharedService,
    private nos: NeworderService
  ) {
    // console.log('size component loaded');
    this.imgsrc = this.nos.Img_HTML_edited;
    this._img = this.imgsrc;
    for (let i = 8; i <= 54; i++) {
      this.customHeight.push(i);
      this.customWidth.push(i);
    }
  }

  ngOnInit() {
    this.imgsrc = this.nos.Img_HTML_edited;
  }

  isImage(str, name) {
    if (str.indexOf(name) !== -1) {
      return true;
    } else {
      return false;
    }
  }

  openDialog() {
    // console.log('show edit clicked');
    this.sharedSvc.ratioHeight = this.selectedCustomHeight;
    this.sharedSvc.ratioWidth = this.selectedCustomWidth;
    this.sharedSvc.maintainAspectRatio = true;
    this.sharedSvc.img = this.nos.Img_HTML_edited;
    const dialogRef = this.dialog.open(CanvasComponent, {
      data: { image: this.nos.Img_HTML_edited },
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '100%',
      width: '100%',
    });

    dialogRef.afterClosed().subscribe((result) => {
      // // console.log('The dialog was closed', result);
      // console.log('The dialog was closed');
      if (result) {
        const img = {
          src: result,
        };
        this.imgsrc = img;
        this.nos.Img_HTML_edited.src = img.src;
      }
    });
  }

  show(a: any, b: any) {
    // console.log('size');
    this.imgsrc = this.nos.Img_HTML_edited;

    const x = parseInt(a); //5000
    const y = parseInt(b); //2000
    // console.log(x, y);
    this.customWidth = [];
    // step 1: calculate aspect ratio  first
    let ratio: number;
    let pixelSize: Number;
    if (x > y) {
      ratio = x / y;
      pixelSize = _.ceil(y / 35, 4);
    } else {
      ratio = y / x;
      pixelSize = _.ceil(x / 35, 4);
    }

    // step 2: find recommended size
    this.res = [];
    this.imgConstant.forEach((ele) => {
      // console.log('ratio: ' + ratio);
      // // console.log(pixelSize);
      // console.log('Round ratio: ' + _.round(ratio, 2));
      const checkRatio = _.round(ratio, 2);
      let finalRatio: any = false;
      if (checkRatio >= 1 && checkRatio <= 1.2) {
        finalRatio = 1;
      } else if (checkRatio >= 1.21 && checkRatio <= 1.29) {
        finalRatio = 1.25;
      } else if (checkRatio >= 1.3 && checkRatio <= 1.4) {
        finalRatio = 1.33;
      } else if (checkRatio >= 1.41 && checkRatio <= 1.55) {
        finalRatio = 1.5;
      } else if (checkRatio >= 1.56 && checkRatio <= 1.7) {
        finalRatio = 1.66;
      } else if (checkRatio >= 1.71 && checkRatio <= 1.9) {
        finalRatio = 1.75;
      } else if (checkRatio >= 1.91 && checkRatio <= 2.15) {
        finalRatio = 2;
      } else if (checkRatio >= 2.16 && checkRatio <= 2.5) {
        finalRatio = 2.35;
      } else if (checkRatio >= 2.51 && checkRatio <= 2.75) {
        finalRatio = 2.5;
      } else if (checkRatio >= 2.76 && checkRatio <= 3.25) {
        finalRatio = 3;
      }
      // let recSize = Math.round(ele * _.round(ratio, 2));
      const recSize = Math.round(ele * finalRatio);
      // console.log('recSize: ' + recSize);
      // removed this block below so as to show all the possible imaage size.
      if (finalRatio && recSize < 96 && pixelSize > ele) {
        this.res.push({
          fixedSize: ele,
          recommendedSize: recSize,
          gallaryWrap: 0,
          rolledCanvas: 0,
          customerSelected: 'none',
        });
      }
    });

    //step 3: find the total feet
    let i = 0;
    for (const ele of this.res) {
      let t1 = _.round(ele.fixedSize / 12, 0.1);
      let t2 = _.round(ele.recommendedSize / 12, 1);

      if (ele.recommendedSize < 13) {
        t2 = 1;
      }
      if (ele.recommendedSize >= 13) {
        t2 = 1.5;
      }
      if (ele.recommendedSize >= 19) {
        t2 = 2;
      }
      if (ele.recommendedSize >= 25) {
        t2 = 2.5;
      }
      if (ele.recommendedSize === 36) {
        t2 = 3;
      }
      if (ele.recommendedSize >= 37) {
        t2 = 3.5;
      }
      if (ele.recommendedSize === 48) {
        t2 = 4;
      }
      if (ele.recommendedSize >= 49) {
        t2 = 4.5;
      }
      if (ele.recommendedSize === 60) {
        t2 = 5;
      }
      if (ele.recommendedSize >= 61) {
        t2 = 5.5;
      }
      if (ele.recommendedSize === 72) {
        t2 = 6;
      }
      if (ele.recommendedSize >= 73) {
        t2 = 6.5;
      }
      if (ele.fixedSize >= 13) {
        t1 = 1.5;
      }
      if (ele.fixedSize >= 19) {
        t1 = 2;
      }
      if (ele.fixedSize >= 25) {
        t1 = 2.5;
      }
      if (ele.fixedSize === 36) {
        t1 = 3;
      }
      if (ele.fixedSize >= 37) {
        t1 = 3.5;
      }
      if (ele.fixedSize === 48) {
        t1 = 4;
      }
      if (ele.fixedSize >= 49) {
        t1 = 4.5;
      }
      if (ele.fixedSize === 60) {
        t1 = 5;
      }
      if (ele.fixedSize >= 61) {
        t1 = 5.5;
      }
      if (ele.fixedSize === 72) {
        t1 = 6;
      }
      if (ele.fixedSize >= 73) {
        t1 = 6.5;
      }
      // console.log(`t1: ${t1}, t2: ${t2}`);
      let total = t1 * t2;
      // console.log('total: ' + total);
      // if (total <= 1) {

      //   const inches = ele.fixedSize * ele.recommendedSize;

      //   const a = Math.round(inches * ((550 / 144)));
      //   const b = Math.round(inches * ((600 / 144)));
      //   // console.log('gt2.5 || lt5 => a:' + a, 'b:' + b);

      //   this.res[i].rolledCanvas = a;
      //   this.res[i].gallaryWrap = b;

      // } else if ((total <= 5) && (total > 2.5)) {
      //   // case 1 - 10.3 = round of to 10
      //   // case 2 - 10.6 = round of to 11

      //   let fixfound = false;
      //   let recfound = false;
      //   for (const it of this.imgConstant) {
      //     if (ele.fixedSize === it) {
      //       fixfound = true;
      //     }
      //     if (ele.recommendedSize === it) {
      //       recfound = true;
      //     }
      //   }

      //   if (fixfound && recfound) {
      //     let a = Math.round(total * (250));
      //     let b = Math.round(total * (450));
      //     // console.log('gt2.5 || lt5 => a:' + a, 'b:' + b);

      //     this.res[i].rolledCanvas = a;
      //     this.res[i].gallaryWrap = b;
      //   } else {
      //     let a = Math.round(total * (250));
      //     let b = Math.round(total * (550));
      //     // console.log('gt2.5 || lt5 and mismatch => a:' + a, 'b:' + b);

      //     this.res[i].rolledCanvas = a;
      //     this.res[i].gallaryWrap = b;
      //   }

      // } else if (total > 5) {
      //   //case 1 - 10.3 = round of to 10
      //   //case 2 - 10.6 = round of to 11

      //   let fixfound = false;
      //   let recfound = false;
      //   for (const it of this.imgConstant) {
      //     if (ele.fixedSize === it) {
      //       fixfound = true;
      //     }
      //     if (ele.recommendedSize === it) {
      //       recfound = true;
      //     }
      //   }

      //   if (fixfound && recfound) {
      //     let a = Math.round(total * (200));
      //     let b = Math.round(total * (375));
      //     // console.log('gt2.5 => a:' + a, 'b:' + b);

      //     this.res[i].rolledCanvas = a;
      //     this.res[i].gallaryWrap = b;
      //   } else {
      //     let a = Math.round(total * (250));
      //     let b = Math.round(total * (550));
      //     // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);

      //     this.res[i].rolledCanvas = a;
      //     this.res[i].gallaryWrap = b;
      //   }
      // } else {
      //   let a = Math.round(total * (350));
      //   let b = Math.round(total * (525));
      //   // console.log('lt2.5 => a:' + a, 'b:' + b);

      //   this.res[i].rolledCanvas = a;
      //   this.res[i].gallaryWrap = b;
      // }
      // this.res[i].rolledCanvas = Math.round(this.res[i].rolledCanvas / 0.60);
      // this.res[i].gallaryWrap = Math.round(this.res[i].gallaryWrap / 0.60);
      const inches = ele.fixedSize * ele.recommendedSize;
      if (total <= 1) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (495 / 144 / 0.6));
          let b = Math.round(inches * (660 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'inches: ' + inches);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (550 / 144 / 0.6));
          let b = Math.round(inches * (770 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'inches: ' + inches);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else if (total <= 2) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (407 / 144 / 0.6));
          let b = Math.round(inches * (572 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (429 / 144 / 0.6));
          let b = Math.round(inches * (715 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else if (total <= 3) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (363 / 144 / 0.6));
          let b = Math.round(inches * (495 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (363 / 144 / 0.6));
          let b = Math.round(inches * (550 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else if (total <= 4) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (330 / 144 / 0.6));
          let b = Math.round(inches * (440 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (352 / 144 / 0.6));
          let b = Math.round(inches * (550 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else if (total <= 5) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (330 / 144 / 0.6));
          let b = Math.round(inches * (440 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (352 / 144 / 0.6));
          let b = Math.round(inches * (495 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else if (total <= 6) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (303 / 144 / 0.6));
          let b = Math.round(inches * (418 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (330 / 144 / 0.6));
          let b = Math.round(inches * (495 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else if (total <= 7) {
        //case 1 - 10.3 = round of to 10
        //case 2 - 10.6 = round of to 11

        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (275 / 144 / 0.6));
          let b = Math.round(inches * (413 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (297 / 144 / 0.6));
          let b = Math.round(inches * (473 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      } else {
        // case 1 - 10.3 = round of to 10
        // case 2 - 10.6 = round of to 11

        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (275 / 144 / 0.6));
          let b = Math.round(inches * (385 / 144 / 0.6));
          // console.log('gt2.5 => a:' + a, 'b:' + b);
          console.log('gt5 => a:' + a, 'b:' + b, 'total: ' + total);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        } else {
          let a = Math.round(inches * (303 / 144 / 0.6));
          let b = Math.round(inches * (440 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);

          this.res[i].rolledCanvas = a;
          this.res[i].gallaryWrap = b;
        }
      }
      i++;
    }
  }

  calculatePixelSize(n: number) {
    return n / 35;
  }

  calculateAspectRatio(a: number, b: number) {
    return Math.round(a / b);
  }

  onSizeSelected(ev: any, i: Size, type: string) {
    this.sharedSvc.cropHeight = undefined;
    this.sharedSvc.cropWidth = undefined;
    this.changeColor(ev);
    this.onSizeChange.emit({ size: i, selectedType: type });
    this.resetRate();
  }

  changeColor(ev: any) {
    Array.from(this.table.nativeElement.children[0].children).forEach(
      (tr: any) => {
        Array.from(tr.children).forEach((td: any) => {
          if (td.bgColor !== '') {
            td.bgColor = '';
          }
        });
      }
    );
    ev.target.bgColor = '#ffd740';
  }

  // showCustomPrice() {
  //   if (this.selectedCustomHeight >= 8 && this.selectedCustomWidth >= 8) {

  //     Array.from(this.table.nativeElement.children[0].children).forEach((tr: any) => {
  //       Array.from(tr.children).forEach((td: any) => {
  //         td.bgColor = "";
  //       })
  //     })

  //     const ele = {
  //       fixedSize: this.selectedCustomHeight,
  //       recommendedSize: this.selectedCustomWidth
  //     };
  //     // const total = t1 * t2;

  //     let t1 = _.round((ele.fixedSize / 12), 0.1);
  //     let t2 = _.round((ele.recommendedSize / 12), 1);
  //     if (ele.recommendedSize < 13) {
  //       t2 = 1;
  //     }
  //     if (ele.recommendedSize >= 13) {
  //       t2 = 1.5;
  //     }
  //     if (ele.recommendedSize >= 19) {
  //       t2 = 2;
  //     }
  //     if (ele.recommendedSize >= 25) {
  //       t2 = 2.5;
  //     }
  //     if (ele.recommendedSize === 36) {
  //       t2 = 3;
  //     }
  //     if (ele.recommendedSize >= 37) {
  //       t2 = 3.5;
  //     }
  //     if (ele.recommendedSize === 48) {
  //       t2 = 4;
  //     }
  //     if (ele.recommendedSize >= 49) {
  //       t2 = 4.5;
  //     }
  //     if (ele.recommendedSize === 60) {
  //       t2 = 5;
  //     }
  //     if (ele.recommendedSize >= 61) {
  //       t2 = 5.5;
  //     }
  //     if (ele.recommendedSize === 72) {
  //       t2 = 6;
  //     }
  //     if (ele.recommendedSize >= 73) {
  //       t2 = 6.5;
  //     }
  //     if (ele.fixedSize >= 13) {
  //       t1 = 1.5;
  //     }
  //     if (ele.fixedSize >= 19) {
  //       t1 = 2;
  //     }
  //     if (ele.fixedSize >= 25) {
  //       t1 = 2.5;
  //     }
  //     if (ele.fixedSize === 36) {
  //       t1 = 3;
  //     }
  //     if (ele.fixedSize >= 37) {
  //       t1 = 3.5;
  //     }
  //     if (ele.fixedSize === 48) {
  //       t1 = 4;
  //     }
  //     if (ele.fixedSize >= 49) {
  //       t1 = 4.5;
  //     }
  //     if (ele.fixedSize === 60) {
  //       t1 = 5;
  //     }
  //     if (ele.fixedSize >= 61) {
  //       t1 = 5.5;
  //     }
  //     if (ele.fixedSize === 72) {
  //       t1 = 6;
  //     }
  //     if (ele.fixedSize >= 73) {
  //       t1 = 6.5;
  //     }
  //     // console.log(`t1: ${t1}, t2: ${t2}`);
  //     let total = t1 * t2;
  //     // console.log('total: ' + total);
  //     if (total <= 1) {

  //       const inches = ele.fixedSize * ele.recommendedSize;

  //       const a = Math.round(inches * ((550 / 144) / 0.60));
  //       const b = Math.round(inches * ((600 / 144) / 0.60));
  //       // console.log('gt2.5 || lt5 => a:' + a, 'b:' + b);

  //       this.ccustomRate = a;
  //       this.gcustomRate = b;

  //     } else if ((total <= 5) && (total > 2.5)) {
  //       //case 1 - 10.3 = round of to 10
  //       //case 2 - 10.6 = round of to 11

  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(total * (250 / 0.60));
  //         let b = Math.round(total * (450 / 0.60));
  //         // console.log('gt2.5 || lt5 => a:' + a, 'b:' + b);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(total * (250 / 0.60));
  //         let b = Math.round(total * (550 / 0.60));
  //         // console.log('gt2.5 || lt5 and mismatch => a:' + a, 'b:' + b);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }

  //     } else if (total > 5) {
  //       //case 1 - 10.3 = round of to 10
  //       //case 2 - 10.6 = round of to 11

  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(total * (200 / 0.60));
  //         let b = Math.round(total * (375 / 0.60));
  //         // console.log('gt2.5 => a:' + a, 'b:' + b);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(total * (250 / 0.60));
  //         let b = Math.round(total * (550 / 0.60));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else {
  //       let a = Math.round(total * (350 / 0.60));
  //       let b = Math.round(total * (525 / 0.60));
  //       // console.log('lt2.5 => a:' + a, 'b:' + b);

  //       this.ccustomRate = a;
  //       this.gcustomRate = b;
  //     }

  //   }

  // }

  showCustomPrice() {
    if (this.selectedCustomHeight >= 8 && this.selectedCustomWidth >= 8) {
      // Array.from(this.table.nativeElement.children[0].children).forEach((tr: any) => {
      //   Array.from(tr.children).forEach((td: any) => {
      //     td.bgColor = "";
      //   })
      // })

      const ele = {
        fixedSize: this.selectedCustomHeight,
        recommendedSize: this.selectedCustomWidth,
      };
      // const total = t1 * t2;

      let t1 = _.round(ele.fixedSize / 12, 0.1);
      let t2 = _.round(ele.recommendedSize / 12, 1);
      if (ele.recommendedSize < 13) {
        t2 = 1;
      }
      if (ele.recommendedSize >= 13) {
        t2 = 1.5;
      }
      if (ele.recommendedSize >= 19) {
        t2 = 2;
      }
      if (ele.recommendedSize >= 25) {
        t2 = 2.5;
      }
      if (ele.recommendedSize === 36) {
        t2 = 3;
      }
      if (ele.recommendedSize >= 37) {
        t2 = 3.5;
      }
      if (ele.recommendedSize === 48) {
        t2 = 4;
      }
      if (ele.recommendedSize >= 49) {
        t2 = 4.5;
      }
      if (ele.recommendedSize === 60) {
        t2 = 5;
      }
      if (ele.recommendedSize >= 61) {
        t2 = 5.5;
      }
      if (ele.recommendedSize === 72) {
        t2 = 6;
      }
      if (ele.recommendedSize >= 73) {
        t2 = 6.5;
      }
      if (ele.fixedSize >= 13) {
        t1 = 1.5;
      }
      if (ele.fixedSize >= 19) {
        t1 = 2;
      }
      if (ele.fixedSize >= 25) {
        t1 = 2.5;
      }
      if (ele.fixedSize === 36) {
        t1 = 3;
      }
      if (ele.fixedSize >= 37) {
        t1 = 3.5;
      }
      if (ele.fixedSize === 48) {
        t1 = 4;
      }
      if (ele.fixedSize >= 49) {
        t1 = 4.5;
      }
      if (ele.fixedSize === 60) {
        t1 = 5;
      }
      if (ele.fixedSize >= 61) {
        t1 = 5.5;
      }
      if (ele.fixedSize === 72) {
        t1 = 6;
      }
      if (ele.fixedSize >= 73) {
        t1 = 6.5;
      }
      // console.log(`t1: ${t1}, t2: ${t2}`);
      let total = t1 * t2;
      // console.log('total: ' + total);

      const inches = ele.fixedSize * ele.recommendedSize;
      if (total <= 1) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (495 / 144 / 0.6));
          let b = Math.round(inches * (660 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'inches: ' + inches);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (550 / 144 / 0.6));
          let b = Math.round(inches * (770 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'inches: ' + inches);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 2) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (407 / 144 / 0.6));
          let b = Math.round(inches * (572 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (429 / 144 / 0.6));
          let b = Math.round(inches * (715 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 3) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (363 / 144 / 0.6));
          let b = Math.round(inches * (495 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (363 / 144 / 0.6));
          let b = Math.round(inches * (550 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 4) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (330 / 144 / 0.6));
          let b = Math.round(inches * (440 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (352 / 144 / 0.6));
          let b = Math.round(inches * (550 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 5) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (330 / 144 / 0.6));
          let b = Math.round(inches * (440 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (352 / 144 / 0.6));
          let b = Math.round(inches * (495 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 6) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (303 / 144 / 0.6));
          let b = Math.round(inches * (418 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (330 / 144 / 0.6));
          let b = Math.round(inches * (495 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 7) {
        //case 1 - 10.3 = round of to 10
        //case 2 - 10.6 = round of to 11

        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (275 / 144 / 0.6));
          let b = Math.round(inches * (413 / 144 / 0.6));
          console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (297 / 144 / 0.6));
          let b = Math.round(inches * (473 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else {
        // case 1 - 10.3 = round of to 10
        // case 2 - 10.6 = round of to 11

        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (275 / 144 / 0.6));
          let b = Math.round(inches * (385 / 144 / 0.6));
          // console.log('gt2.5 => a:' + a, 'b:' + b);
          console.log('gt5 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (303 / 144 / 0.6));
          let b = Math.round(inches * (440 / 144 / 0.6));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      }
    }
  }

  // showCustomPrice() {
  //   if (this.selectedCustomHeight >= 8 && this.selectedCustomWidth >= 8) {

  //     Array.from(this.table.nativeElement.children[0].children).forEach((tr: any) => {
  //       Array.from(tr.children).forEach((td: any) => {
  //         td.bgColor = "";
  //       })
  //     })

  //     const t1 = _.round((this.selectedCustomHeight / 12), 0.1);
  //     const t2 = _.round((this.selectedCustomWidth / 12), 1);
  //     const total = t1 * t2;

  //     if (total > 2.5) {
  //       this.ccustomRate = _.round((total * (200 / 0.65)));
  //       this.gcustomRate = _.round(total * (400 / 0.65));
  //     } else {
  //       this.ccustomRate = _.round((total * (350 / 0.65)));
  //       this.gcustomRate = _.round(total * (550 / 0.65));
  //     }

  //   }

  // }

  resetRate() {
    if (this.selectedCustomHeight && this.selectedCustomWidth) {
      this.selectedCustomHeight = undefined;
      this.selectedCustomWidth = undefined;
      this.gcustomRate = 0;
      this.ccustomRate = 0;
    }
  }

  setCustomSize(selectedType: any) {
    let s: Size;
    if (this.nos.File_edited) {
      this.sharedSvc.img = this.imgsrc;
      s = {
        fixedSize: this.selectedCustomHeight,
        recommendedSize: this.selectedCustomWidth,
        gallaryWrap: this.gcustomRate,
        rolledCanvas: this.ccustomRate,
        customerSelected: 'none',
      };
    } else {
      alert('crop image first');
    }

    // if(this.selectedCustomHeight < this.selectedCustomWidth){
    //   s={
    //     fixedSize:this.selectedCustomHeight,
    //     recommendedSize:this.selectedCustomWidth,
    //     gallaryWrap:this.gcustomRate,
    //     rolledCanvas:this.ccustomRate
    //   }

    // }else{
    //   s={
    //     fixedSize:this.sel,
    //     recommendedSize:this.selectedCustomHeight,
    //     gallaryWrap:this.gcustomRate,
    //     rolledCanvas:this.ccustomRate
    //   }
    // }
    this.onSizeChange.emit({ size: s, selectedType: selectedType });
  }

  getDiscount(amount) {
    // let original_amount = amount;
    // let iscount_amount = amount * (parseInt('40') / 100);
    let val: any = amount - amount * (parseInt('40') / 100);
    val = val.toFixed(2);
    return 'After Discount: Rs. ' + val;
  }
}
