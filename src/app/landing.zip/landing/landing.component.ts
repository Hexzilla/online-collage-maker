import { Component, OnInit } from "@angular/core";
import { ProductService } from "../product.service";
import { Content } from "src/datamodel/content";
import { Router } from "@angular/router";
import { MatCarousel, MatCarouselComponent } from "@ngmodule/material-carousel";
import * as _ from "lodash";

@Component({
  selector: "app-landing",
  templateUrl: "./landing.component.html",
  styleUrls: ["./landing.component.scss"],
})
export class LandingComponent implements OnInit {
  slides = [
    {
      image: "assets/banners/banner1.webp",
    },
    {
      image: "assets/banners/banner2.webp",
    },
    {
      image: "assets/banners/banner3.webp",
    },
    // {
    //   image: 'assets/banners/4.jpeg'
    // },
    // {
    //   image: 'assets/banners/5.jpeg'
    // },
    // {
    //   image: 'assets/banners/6.jpeg'
    // },
    // {
    //   image: 'assets/banners/7.jpeg'
    // }
  ];

  customHeight: number[] = [];
  customWidth: number[] = [];
  selectedCustomHeight: number;
  selectedCustomWidth: number;
  gcustomRate: number;
  ccustomRate: number;
  imgConstant = [8, 10, 12, 16, 18, 20, 24, 30, 36, 42, 48, 60];

  contents: Content[];

  prices = [
    {
      size: '8" x 8"',
      // value: "310",
      value: "488",
      yourPrice: "220",
    },
    {
      size: '8" x 12"',
      value: "733",
      yourPrice: "330",
    },
    {
      size: '18" x 24"',
      value: "2420",
      yourPrice: "1089",
    },
    {
      size: '24" x 36"',
      value: "4040",
      yourPrice: "1818",
    },
    {
      size: '36" x 48"',
      value: "7333",
      yourPrice: "3300",
    },
    // {
    //   size: '50" x 90"',
    //   value: "16600",
    //   yourPrice: "7650",
    // },
  ];

  constructor(
    // private prdsvc: ProductService,
    private router: Router
  ) {
    for (let i = 8; i <= 54; i++) {
      this.customHeight.push(i);
    }
    for (let i = 8; i <= 90; i++) {
      this.customWidth.push(i);
    }
    // prdsvc.getCanvasContent().subscribe((r: Content[]) => {
    //   this.contents = r;
    // });
  }

  ngOnInit() {
    document.querySelector("mat-sidenav-content").scroll(0, 0);
  }

  // showCustomPrice() {
  //   if (this.selectedCustomHeight >= 8 && this.selectedCustomWidth >= 8) {
  //     // Array.from(this.table.nativeElement.children[0].children).forEach((tr: any) => {
  //     //   Array.from(tr.children).forEach((td: any) => {
  //     //     td.bgColor = "";
  //     //   })
  //     // })

  //     const ele = {
  //       fixedSize: this.selectedCustomHeight,
  //       recommendedSize: this.selectedCustomWidth,
  //     };
  //     // const total = t1 * t2;

  //     let t1 = _.round(ele.fixedSize / 12, 0.1);
  //     let t2 = _.round(ele.recommendedSize / 12, 1);
  //     if (ele.recommendedSize < 13) {
  //       t2 = 1;
  //     }
  //     if (ele.recommendedSize >= 13) {
  //       t2 = 1.5;
  //     }
  //     if (ele.recommendedSize >= 19) {
  //       t2 = 2;
  //     }
  //     if (ele.recommendedSize >= 25) {
  //       t2 = 2.5;
  //     }
  //     if (ele.recommendedSize === 36) {
  //       t2 = 3;
  //     }
  //     if (ele.recommendedSize >= 37) {
  //       t2 = 3.5;
  //     }
  //     if (ele.recommendedSize === 48) {
  //       t2 = 4;
  //     }
  //     if (ele.recommendedSize >= 49) {
  //       t2 = 4.5;
  //     }
  //     if (ele.recommendedSize === 60) {
  //       t2 = 5;
  //     }
  //     if (ele.recommendedSize >= 61) {
  //       t2 = 5.5;
  //     }
  //     if (ele.recommendedSize === 72) {
  //       t2 = 6;
  //     }
  //     if (ele.recommendedSize >= 73) {
  //       t2 = 6.5;
  //     }
  //     if (ele.fixedSize >= 13) {
  //       t1 = 1.5;
  //     }
  //     if (ele.fixedSize >= 19) {
  //       t1 = 2;
  //     }
  //     if (ele.fixedSize >= 25) {
  //       t1 = 2.5;
  //     }
  //     if (ele.fixedSize === 36) {
  //       t1 = 3;
  //     }
  //     if (ele.fixedSize >= 37) {
  //       t1 = 3.5;
  //     }
  //     if (ele.fixedSize === 48) {
  //       t1 = 4;
  //     }
  //     if (ele.fixedSize >= 49) {
  //       t1 = 4.5;
  //     }
  //     if (ele.fixedSize === 60) {
  //       t1 = 5;
  //     }
  //     if (ele.fixedSize >= 61) {
  //       t1 = 5.5;
  //     }
  //     if (ele.fixedSize === 72) {
  //       t1 = 6;
  //     }
  //     if (ele.fixedSize >= 73) {
  //       t1 = 6.5;
  //     }
  //     // console.log(`t1: ${t1}, t2: ${t2}`);
  //     let total = t1 * t2;
  //     // console.log('total: ' + total);
  //     const inches = ele.fixedSize * ele.recommendedSize;
  //     if (total <= 1) {
  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (500 / 144));
  //         let b = Math.round(inches * (650 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "inches: " + inches);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (550 / 144));
  //         let b = Math.round(inches * (750 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'inches: ' + inches);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else if (total <= 2) {
  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (390 / 144));
  //         let b = Math.round(inches * (540 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (390 / 144));
  //         let b = Math.round(inches * (670 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else if (total <= 3) {
  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (330 / 144));
  //         let b = Math.round(inches * (520 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (330 / 144));
  //         let b = Math.round(inches * (630 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else if (total <= 4) {
  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (270 / 144));
  //         let b = Math.round(inches * (500 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (320 / 144));
  //         let b = Math.round(inches * (580 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else if (total <= 5) {
  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (270 / 144));
  //         let b = Math.round(inches * (470 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (320 / 144));
  //         let b = Math.round(inches * (530 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else if (total <= 6) {
  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (230 / 144));
  //         let b = Math.round(inches * (420 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (270 / 144));
  //         let b = Math.round(inches * (480 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else if (total <= 7) {
  //       //case 1 - 10.3 = round of to 10
  //       //case 2 - 10.6 = round of to 11

  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (230 / 144));
  //         let b = Math.round(inches * (395 / 144));
  //         console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (260 / 144));
  //         let b = Math.round(inches * (430 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
  //         // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     } else {
  //       // case 1 - 10.3 = round of to 10
  //       // case 2 - 10.6 = round of to 11

  //       let fixfound = false;
  //       let recfound = false;
  //       for (const it of this.imgConstant) {
  //         if (ele.fixedSize === it) {
  //           fixfound = true;
  //         }
  //         if (ele.recommendedSize === it) {
  //           recfound = true;
  //         }
  //       }

  //       if (fixfound && recfound) {
  //         let a = Math.round(inches * (230 / 144));
  //         let b = Math.round(inches * (350 / 144));
  //         // console.log('gt2.5 => a:' + a, 'b:' + b);
  //         console.log("gt5 => a:" + a, "b:" + b, "total: " + total);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       } else {
  //         let a = Math.round(inches * (260 / 144));
  //         let b = Math.round(inches * (400 / 144));
  //         // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);

  //         this.ccustomRate = a;
  //         this.gcustomRate = b;
  //       }
  //     }
  //   }
  // }

  showCustomPrice() {
    if (this.selectedCustomHeight >= 8 && this.selectedCustomWidth >= 8) {
      // Array.from(this.table.nativeElement.children[0].children).forEach((tr: any) => {
      //   Array.from(tr.children).forEach((td: any) => {
      //     td.bgColor = "";
      //   })
      // })

      const ele = {
        fixedSize: this.selectedCustomHeight,
        recommendedSize: this.selectedCustomWidth,
      };
      // const total = t1 * t2;

      let t1 = _.round(ele.fixedSize / 12, 0.1);
      let t2 = _.round(ele.recommendedSize / 12, 1);
      if (ele.recommendedSize < 13) {
        t2 = 1;
      }
      if (ele.recommendedSize >= 13) {
        t2 = 1.5;
      }
      if (ele.recommendedSize >= 19) {
        t2 = 2;
      }
      if (ele.recommendedSize >= 25) {
        t2 = 2.5;
      }
      if (ele.recommendedSize === 36) {
        t2 = 3;
      }
      if (ele.recommendedSize >= 37) {
        t2 = 3.5;
      }
      if (ele.recommendedSize === 48) {
        t2 = 4;
      }
      if (ele.recommendedSize >= 49) {
        t2 = 4.5;
      }
      if (ele.recommendedSize === 60) {
        t2 = 5;
      }
      if (ele.recommendedSize >= 61) {
        t2 = 5.5;
      }
      if (ele.recommendedSize === 72) {
        t2 = 6;
      }
      if (ele.recommendedSize >= 73) {
        t2 = 6.5;
      }
      if (ele.fixedSize >= 13) {
        t1 = 1.5;
      }
      if (ele.fixedSize >= 19) {
        t1 = 2;
      }
      if (ele.fixedSize >= 25) {
        t1 = 2.5;
      }
      if (ele.fixedSize === 36) {
        t1 = 3;
      }
      if (ele.fixedSize >= 37) {
        t1 = 3.5;
      }
      if (ele.fixedSize === 48) {
        t1 = 4;
      }
      if (ele.fixedSize >= 49) {
        t1 = 4.5;
      }
      if (ele.fixedSize === 60) {
        t1 = 5;
      }
      if (ele.fixedSize >= 61) {
        t1 = 5.5;
      }
      if (ele.fixedSize === 72) {
        t1 = 6;
      }
      if (ele.fixedSize >= 73) {
        t1 = 6.5;
      }
      // console.log(`t1: ${t1}, t2: ${t2}`);
      let total = t1 * t2;
      // console.log('total: ' + total);

      const inches = ele.fixedSize * ele.recommendedSize;
      if (total <= 1) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (495 / 144));
          let b = Math.round(inches * (660 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "inches: " + inches);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (550 / 144));
          let b = Math.round(inches * (770 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'inches: ' + inches);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 2) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (407 / 144));
          let b = Math.round(inches * (572 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (429 / 144));
          let b = Math.round(inches * (715 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 3) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (363 / 144));
          let b = Math.round(inches * (495 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (363 / 144));
          let b = Math.round(inches * (550 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 4) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (330 / 144));
          let b = Math.round(inches * (440 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (352 / 144));
          let b = Math.round(inches * (550 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 5) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (330 / 144));
          let b = Math.round(inches * (440 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (352 / 144));
          let b = Math.round(inches * (495 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 6) {
        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (303 / 144));
          let b = Math.round(inches * (418 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (330 / 144));
          let b = Math.round(inches * (495 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else if (total <= 7) {
        //case 1 - 10.3 = round of to 10
        //case 2 - 10.6 = round of to 11

        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (275 / 144));
          let b = Math.round(inches * (413 / 144));
          console.log("gt4 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (297 / 144));
          let b = Math.round(inches * (473 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);
          // console.log('gt4 => a:' + a, 'b:' + b, 'total: ' + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      } else {
        // case 1 - 10.3 = round of to 10
        // case 2 - 10.6 = round of to 11

        let fixfound = false;
        let recfound = false;
        for (const it of this.imgConstant) {
          if (ele.fixedSize === it) {
            fixfound = true;
          }
          if (ele.recommendedSize === it) {
            recfound = true;
          }
        }

        if (fixfound && recfound) {
          let a = Math.round(inches * (275 / 144));
          let b = Math.round(inches * (385 / 144));
          // console.log('gt2.5 => a:' + a, 'b:' + b);
          console.log("gt5 => a:" + a, "b:" + b, "total: " + total);

          this.ccustomRate = a;
          this.gcustomRate = b;
        } else {
          let a = Math.round(inches * (303 / 144));
          let b = Math.round(inches * (440 / 144));
          // console.log('gt2.5 and mismatch => a:' + a, 'b:' + b);

          this.ccustomRate = a;
          this.gcustomRate = b;
        }
      }
    }
  }

  order(p: Content) {
    if (p.type == "canvas") {
      this.router.navigateByUrl("order");
    }
  }
}
